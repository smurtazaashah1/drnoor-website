var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/2c1a7_next_3e3e21f7._.js")
R.c("server/chunks/[root-of-the-server]__4a6f0e1d._.js")
R.m("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
