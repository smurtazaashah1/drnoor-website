module.exports = [
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/favicon.ico (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.fff883ed.ico");}),
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/favicon.ico.mjs { IMAGE => \"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/favicon.ico (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__["default"],
    width: 1543,
    height: 1498
};
}),
];

//# sourceMappingURL=drnoor-94468adde2afb22849fbd641cb281644be1032bc_app_da2ac7b5._.js.map