globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/2c1a7_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_dea6b86f._.js",
    "static/chunks/2c1a7_next_dist_compiled_react-dom_9594978d._.js",
    "static/chunks/2c1a7_next_dist_compiled_next-devtools_index_852fb623.js",
    "static/chunks/2c1a7_next_dist_compiled_adb56aea._.js",
    "static/chunks/2c1a7_next_dist_client_24fafe99._.js",
    "static/chunks/2c1a7_next_dist_5dfe6251._.js",
    "static/chunks/2c1a7_@swc_helpers_cjs_5e7bc0c4._.js",
    "static/chunks/drnoor-94468adde2afb22849fbd641cb281644be1032bc_a0ff3932._.js",
    "static/chunks/turbopack-drnoor-94468adde2afb22849fbd641cb281644be1032bc_a5f36959._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];