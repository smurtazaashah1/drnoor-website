(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/26bed_de2afb22849fbd641cb281644be1032bc_app_components_ClassroomSlideshow_tsx_c2006181._.js"
],
    source: "dynamic"
});
