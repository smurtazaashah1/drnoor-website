(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TestimonialsSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// Import Swiper statically to avoid module loading issues
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/swiper-react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/modules/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/modules/navigation.mjs [app-client] (ecmascript) <export default as Navigation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/modules/pagination.mjs [app-client] (ecmascript) <export default as Pagination>");
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$modules$2f$autoplay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Autoplay$3e$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/modules/autoplay.mjs [app-client] (ecmascript) <export default as Autoplay>");
'use client';
;
;
;
;
;
;
// Testimonial Card Component
const TestimonialCard = (param)=>{
    let { testimonial } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group relative h-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white/80 backdrop-blur-xl border border-gray-200/50 rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-500 hover:border-yellow-400/30 hover:shadow-yellow-400/10 transform hover:scale-105 h-full flex flex-col",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 bg-gradient-to-br from-yellow-400/0 via-yellow-400/5 to-yellow-400/0 opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-500"
                }, void 0, false, {
                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative z-10 flex flex-col h-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-1 mb-4",
                            children: [
                                ...Array(testimonial.rating)
                            ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-5 h-5 text-yellow-400 fill-current",
                                    viewBox: "0 0 20 20",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                                    }, void 0, false, {
                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                                        lineNumber: 43,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, i, false, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                                    lineNumber: 38,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-700 mb-6 leading-relaxed flex-grow",
                            children: [
                                '"',
                                testimonial.quote,
                                '"'
                            ]
                        }, void 0, true, {
                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg ".concat(testimonial.avatar.gradient),
                                    children: testimonial.avatar.letter
                                }, void 0, false, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                                    lineNumber: 55,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "font-semibold text-gray-900",
                                            children: testimonial.name
                                        }, void 0, false, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                                            lineNumber: 61,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-gray-600",
                                            children: testimonial.role
                                        }, void 0, false, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                                    lineNumber: 60,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = TestimonialCard;
// Swiper Component
const SwiperTestimonials = (param)=>{
    let { testimonials } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Swiper"], {
            modules: [
                __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"],
                __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__["Pagination"],
                __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$modules$2f$autoplay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Autoplay$3e$__["Autoplay"]
            ],
            spaceBetween: 30,
            slidesPerView: 1,
            navigation: true,
            pagination: {
                clickable: true
            },
            autoplay: {
                delay: 5000,
                disableOnInteraction: false
            },
            breakpoints: {
                640: {
                    slidesPerView: 1,
                    spaceBetween: 20
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 30
                },
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 30
                }
            },
            className: "testimonials-swiper",
            children: testimonials.map((testimonial)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TestimonialCard, {
                        testimonial: testimonial
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                        lineNumber: 109,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, testimonial.id, false, {
                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                    lineNumber: 108,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)))
        }, void 0, false, {
            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
            lineNumber: 81,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = SwiperTestimonials;
function TestimonialsSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-20 bg-gradient-to-br from-gray-50 to-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mb-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-4xl font-bold text-gray-900 mb-4",
                            children: "What Our Students Say"
                        }, void 0, false, {
                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                            lineNumber: 122,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl text-gray-600 max-w-3xl mx-auto",
                            children: "Discover how Dr. Noor Academy has transformed the learning journey of thousands of students worldwide"
                        }, void 0, false, {
                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                            lineNumber: 125,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                    lineNumber: 121,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SwiperTestimonials, {
                        testimonials: testimonials
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
                    lineNumber: 131,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
            lineNumber: 120,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx",
        lineNumber: 119,
        columnNumber: 5
    }, this);
}
_c2 = TestimonialsSection;
// Testimonials data
const testimonials = [
    {
        id: 1,
        name: 'Sarah Ahmed',
        role: 'A Level Biology Student',
        quote: "Dr. Noor's teaching method made complex biological processes so easy to understand. I went from struggling with genetics to scoring an A* in my A Level Biology!",
        rating: 5,
        avatar: {
            letter: 'S',
            gradient: 'bg-gradient-to-br from-pink-500 to-rose-500'
        }
    },
    {
        id: 2,
        name: 'Ahmed Hassan',
        role: 'O Level Chemistry Student',
        quote: 'The interactive experiments and clear explanations helped me grasp chemistry concepts that seemed impossible before. Highly recommend Dr. Noor Academy!',
        rating: 5,
        avatar: {
            letter: 'A',
            gradient: 'bg-gradient-to-br from-blue-500 to-cyan-500'
        }
    },
    {
        id: 3,
        name: 'Fatima Khan',
        role: 'Medical Student',
        quote: 'Thanks to the solid foundation I built at Dr. Noor Academy, I was well-prepared for medical school. The career guidance was invaluable!',
        rating: 5,
        avatar: {
            letter: 'F',
            gradient: 'bg-gradient-to-br from-purple-500 to-indigo-500'
        }
    },
    {
        id: 4,
        name: 'Omar Ali',
        role: 'A Level Chemistry Student',
        quote: 'Dr. Noor made organic chemistry feel like solving puzzles. The personalized attention and practice materials were exactly what I needed.',
        rating: 5,
        avatar: {
            letter: 'O',
            gradient: 'bg-gradient-to-br from-green-500 to-emerald-500'
        }
    },
    {
        id: 5,
        name: 'Zara Malik',
        role: 'O Level Biology Student',
        quote: 'The visual aids and practical examples made learning biology so engaging. I never thought I could love science this much!',
        rating: 5,
        avatar: {
            letter: 'Z',
            gradient: 'bg-gradient-to-br from-yellow-500 to-orange-500'
        }
    },
    {
        id: 6,
        name: 'Hassan Sheikh',
        role: 'Pre-Medical Student',
        quote: 'The comprehensive preparation and mentorship at Dr. Noor Academy gave me the confidence to pursue my medical career dreams.',
        rating: 5,
        avatar: {
            letter: 'H',
            gradient: 'bg-gradient-to-br from-teal-500 to-cyan-500'
        }
    }
];
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "TestimonialCard");
__turbopack_context__.k.register(_c1, "SwiperTestimonials");
__turbopack_context__.k.register(_c2, "TestimonialsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=26bed_de2afb22849fbd641cb281644be1032bc_app_components_SwiperTestimonials_tsx_adeb9ebb._.js.map