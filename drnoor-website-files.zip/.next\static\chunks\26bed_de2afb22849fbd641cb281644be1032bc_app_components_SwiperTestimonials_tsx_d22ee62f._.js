(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2c1a7_swiper_706c6739._.js",
  "static/chunks/26bed_de2afb22849fbd641cb281644be1032bc_app_components_SwiperTestimonials_tsx_adeb9ebb._.js",
  "static/chunks/2c1a7_swiper_ef0bbc0f._.css"
],
    source: "dynamic"
});
