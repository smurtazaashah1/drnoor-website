(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const Schedule = ()=>{
    _s();
    const [activeLocation, setActiveLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('Online');
    const locations = [
        'Online',
        'Bahadurabad',
        'North Nazimabad',
        'Malir',
        'Gulshan',
        'Johar'
    ];
    const scheduleData = {
        Online: [
            {
                day: 'Tuesday & Thursday',
                subject: 'AS Chemistry',
                time: '4-5 PM',
                group: ''
            },
            {
                day: 'Tuesday & Thursday',
                subject: 'OL/IGCSE Chemistry',
                time: '5-6 PM',
                group: 'Group A'
            },
            {
                day: 'Tuesday & Thursday',
                subject: 'OL/IGCSE Biology',
                time: '6-7 PM',
                group: 'Group B'
            },
            {
                day: 'Monday & Wednesday',
                subject: 'A2 Chemistry',
                time: '8-9 PM',
                group: ''
            },
            {
                day: 'Thursday & Friday',
                subject: 'OL/IGCSE Biology',
                time: '8-9 PM',
                group: 'Group A'
            },
            {
                day: 'Tuesday',
                subject: 'OL/IGCSE Chemistry',
                time: '8-9 PM',
                group: 'Group B'
            },
            {
                day: 'Friday',
                subject: 'OL/IGCSE Chemistry',
                time: '6-7 PM',
                group: ''
            },
            {
                day: 'Saturday & Sunday',
                subject: 'AS Biology',
                time: '5:30-6:30 PM',
                group: ''
            },
            {
                day: 'Saturday & Sunday',
                subject: 'A2 Biology',
                time: '6:45-7:45 PM',
                group: ''
            }
        ],
        Bahadurabad: [
            {
                day: 'Tuesday & Thursday',
                subject: 'AS Chemistry',
                time: '4-5 PM',
                group: ''
            },
            {
                day: 'Tuesday & Thursday',
                subject: 'OL/IGCSE Chemistry',
                time: '5-6 PM',
                group: 'Group A'
            },
            {
                day: 'Tuesday & Thursday',
                subject: 'OL/IGCSE Biology',
                time: '6-7 PM',
                group: 'Group B'
            }
        ],
        'North Nazimabad': [
            {
                day: 'Monday & Wednesday',
                subject: 'OL/IGCSE Biology',
                time: '4-5 PM',
                group: ''
            },
            {
                day: 'Monday & Wednesday',
                subject: 'OL/IGCSE Biology',
                time: '6-7 PM',
                group: ''
            },
            {
                day: 'Monday & Wednesday',
                subject: 'OL/IGCSE Chemistry',
                time: '7-8 PM',
                group: ''
            },
            {
                day: 'Monday & Wednesday',
                subject: 'A2 Chemistry',
                time: '8-9 PM',
                group: ''
            }
        ],
        Malir: [
            {
                day: 'Tuesday',
                subject: 'OL/IGCSE Chemistry',
                time: '8-9 PM',
                group: ''
            },
            {
                day: 'Friday',
                subject: 'OL/IGCSE Chemistry',
                time: '6-7 PM',
                group: ''
            }
        ],
        Gulshan: [
            {
                day: 'Friday',
                subject: 'OL/IGCSE Biology',
                time: '3-4 PM',
                group: ''
            },
            {
                day: 'Saturday',
                subject: 'OL/IGCSE Biology',
                time: '4-5 PM',
                group: ''
            },
            {
                day: 'Saturday',
                subject: 'OL/IGCSE Chemistry',
                time: '8-9 PM',
                group: ''
            },
            {
                day: 'Sunday',
                subject: 'OL/IGCSE Chemistry',
                time: '4:30-5:30 PM',
                group: ''
            },
            {
                day: 'Saturday & Sunday',
                subject: 'AS Biology',
                time: '5:30-6:30 PM',
                group: ''
            },
            {
                day: 'Saturday & Sunday',
                subject: 'A2 Biology',
                time: '6:45-7:45 PM',
                group: ''
            }
        ],
        Johar: [
            {
                day: 'Saturday & Sunday',
                subject: 'OL/IGCSE Chemistry',
                time: '12:30-1:30 PM',
                group: ''
            },
            {
                day: 'Saturday & Sunday',
                subject: 'OL/IGCSE Biology',
                time: '1:30-2:30 PM',
                group: ''
            },
            {
                day: 'Saturday & Sunday',
                subject: 'AS Biology',
                time: '2:30-3:30 PM',
                group: ''
            }
        ]
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "relative py-20 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-gradient-to-t from-white/50 via-transparent to-transparent pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                lineNumber: 203,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-0 left-1/4 w-96 h-96 bg-amber-400/5 rounded-full blur-3xl pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                lineNumber: 204,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-0 right-1/4 w-96 h-96 bg-blue-400/5 rounded-full blur-3xl pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                lineNumber: 205,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-10 max-w-7xl mx-auto px-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center mb-16",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-4xl md:text-5xl font-bold text-gray-900 mb-4",
                                children: "Class Schedule"
                            }, void 0, false, {
                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                lineNumber: 210,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-lg text-gray-600 max-w-2xl mx-auto",
                                children: "Check your class timings by location."
                            }, void 0, false, {
                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                lineNumber: 213,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-6 h-1 w-24 bg-gradient-to-r from-amber-400 to-yellow-300 mx-auto rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                lineNumber: 216,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                        lineNumber: 209,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-12",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap justify-center gap-2 md:gap-4",
                            children: locations.map((location)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setActiveLocation(location),
                                    className: "px-4 py-3 md:px-6 md:py-3 rounded-xl font-medium text-sm md:text-base transition-all duration-300 transform hover:scale-105 ".concat(activeLocation === location ? 'bg-gradient-to-r from-amber-400 to-yellow-300 text-white shadow-lg shadow-amber-400/30' : 'bg-white text-gray-700 hover:bg-gray-50 shadow-md hover:shadow-lg border border-gray-200'),
                                    children: location
                                }, location, false, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                    lineNumber: 223,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                            lineNumber: 221,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                        lineNumber: 220,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-6 md:p-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-2xl font-bold text-gray-900 mb-6 text-center",
                                    children: [
                                        activeLocation,
                                        " Schedule"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                    lineNumber: 241,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden md:block overflow-x-auto",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "w-full",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "border-b-2 border-gray-100",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-4 px-6 font-semibold text-gray-700 text-lg",
                                                            children: "Day"
                                                        }, void 0, false, {
                                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                            lineNumber: 250,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-4 px-6 font-semibold text-gray-700 text-lg",
                                                            children: "Subject"
                                                        }, void 0, false, {
                                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                            lineNumber: 253,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-4 px-6 font-semibold text-gray-700 text-lg",
                                                            children: "Time"
                                                        }, void 0, false, {
                                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                            lineNumber: 256,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "text-left py-4 px-6 font-semibold text-gray-700 text-lg",
                                                            children: "Group"
                                                        }, void 0, false, {
                                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                            lineNumber: 259,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                    lineNumber: 249,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                lineNumber: 248,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                children: scheduleData[activeLocation].map((entry, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                        className: "border-b border-gray-50 hover:bg-gray-50/50 transition-colors duration-200",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-4 px-6 text-gray-800 font-medium",
                                                                children: entry.day
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 270,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-4 px-6",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-blue-100 to-indigo-100 text-blue-800",
                                                                    children: entry.subject
                                                                }, void 0, false, {
                                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                    lineNumber: 274,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 273,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-4 px-6 text-gray-700 font-mono",
                                                                children: entry.time
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 278,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-4 px-6",
                                                                children: entry.group && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-amber-100 text-amber-800",
                                                                    children: entry.group
                                                                }, void 0, false, {
                                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                    lineNumber: 283,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 281,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, index, true, {
                                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                        lineNumber: 266,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                lineNumber: 264,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                        lineNumber: 247,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                    lineNumber: 246,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "md:hidden space-y-4",
                                    children: scheduleData[activeLocation].map((entry, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-4 border border-gray-100",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-between items-start",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm font-semibold text-gray-600",
                                                                children: "Day:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 303,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm text-gray-800 font-medium text-right flex-1 ml-2",
                                                                children: entry.day
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 306,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                        lineNumber: 302,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-between items-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm font-semibold text-gray-600",
                                                                children: "Subject:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 311,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-blue-100 to-indigo-100 text-blue-800",
                                                                children: entry.subject
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 314,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                        lineNumber: 310,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-between items-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm font-semibold text-gray-600",
                                                                children: "Time:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 319,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm text-gray-700 font-mono",
                                                                children: entry.time
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 322,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                        lineNumber: 318,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    entry.group && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-between items-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm font-semibold text-gray-600",
                                                                children: "Group:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 328,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-amber-100 text-amber-800",
                                                                children: entry.group
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                                lineNumber: 331,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                        lineNumber: 327,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                lineNumber: 301,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, index, false, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                            lineNumber: 297,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                    lineNumber: 295,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                scheduleData[activeLocation].length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center py-12",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-400 mb-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-16 h-16 mx-auto",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 1.5,
                                                    d: "M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 0V6a2 2 0 012-2h4a2 2 0 012 2v1m-6 0h8m-8 0H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V9a2 2 0 00-2-2h-2m-8 0V7"
                                                }, void 0, false, {
                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                    lineNumber: 351,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                                lineNumber: 345,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                            lineNumber: 344,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-500 text-lg",
                                            children: "No classes scheduled for this location."
                                        }, void 0, false, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                            lineNumber: 359,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                                    lineNumber: 343,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                            lineNumber: 240,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                        lineNumber: 239,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
                lineNumber: 207,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx",
        lineNumber: 201,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Schedule, "9PoFi/c2/QJLo/kXO0q4cQwyaW4=");
_c = Schedule;
const __TURBOPACK__default__export__ = Schedule;
var _c;
__turbopack_context__.k.register(_c, "Schedule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=be596_or-94468adde2afb22849fbd641cb281644be1032bc_app_components_Schedule_tsx_2a3987ef._.js.map