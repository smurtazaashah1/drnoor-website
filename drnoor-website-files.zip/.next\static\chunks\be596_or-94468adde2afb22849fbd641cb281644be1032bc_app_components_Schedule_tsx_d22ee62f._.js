(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/be596_or-94468adde2afb22849fbd641cb281644be1032bc_app_components_Schedule_tsx_2a3987ef._.js"
],
    source: "dynamic"
});
