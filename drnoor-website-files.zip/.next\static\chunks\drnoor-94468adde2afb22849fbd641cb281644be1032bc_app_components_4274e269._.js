(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/ClassroomSlideshow.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/26bed_de2afb22849fbd641cb281644be1032bc_app_components_ClassroomSlideshow_tsx_c2006181._.js",
  "static/chunks/26bed_de2afb22849fbd641cb281644be1032bc_app_components_ClassroomSlideshow_tsx_d22ee62f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/ClassroomSlideshow.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/be596_or-94468adde2afb22849fbd641cb281644be1032bc_app_components_Schedule_tsx_2a3987ef._.js",
  "static/chunks/be596_or-94468adde2afb22849fbd641cb281644be1032bc_app_components_Schedule_tsx_d22ee62f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/Schedule.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/2c1a7_swiper_706c6739._.js",
  "static/chunks/26bed_de2afb22849fbd641cb281644be1032bc_app_components_SwiperTestimonials_tsx_adeb9ebb._.js",
  {
    "path": "static/chunks/2c1a7_swiper_ef0bbc0f._.css",
    "included": [
      "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/swiper.css [app-client] (css)",
      "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/modules/navigation.css [app-client] (css)",
      "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/swiper/modules/pagination.css [app-client] (css)"
    ],
    "moduleChunks": [
      "static/chunks/2c1a7_swiper_swiper_css_bad6b30c._.single.css",
      "static/chunks/2c1a7_swiper_modules_navigation_css_bad6b30c._.single.css",
      "static/chunks/2c1a7_swiper_modules_pagination_css_bad6b30c._.single.css"
    ]
  },
  "static/chunks/26bed_de2afb22849fbd641cb281644be1032bc_app_components_SwiperTestimonials_tsx_d22ee62f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/SwiperTestimonials.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/f2147_68adde2afb22849fbd641cb281644be1032bc_app_components_LazyFAQSection_tsx_8d8c3f4a._.js",
  "static/chunks/f2147_68adde2afb22849fbd641cb281644be1032bc_app_components_LazyFAQSection_tsx_d22ee62f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);