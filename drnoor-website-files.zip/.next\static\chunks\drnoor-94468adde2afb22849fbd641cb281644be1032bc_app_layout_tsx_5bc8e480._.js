(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__425c13b8._.js",
  "static/chunks/2c1a7_next_4da44304._.js",
  "static/chunks/[root-of-the-server]__6aff3c08._.css"
],
    source: "dynamic"
});
