(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/drnoor-94468adde2afb22849fbd641cb281644be1032bc_app_components_4274e269._.js",
  "static/chunks/drnoor-94468adde2afb22849fbd641cb281644be1032bc_app_page_tsx_4f2e7a0d._.js",
  "static/chunks/2c1a7_next_dist_shared_lib_a88c5392._.js"
],
    source: "dynamic"
});
