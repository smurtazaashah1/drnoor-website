(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const LazyFAQSection = (param)=>{
    let { isVisible } = param;
    _s();
    const [openFAQ, setOpenFAQ] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const toggleFAQ = (index)=>{
        setOpenFAQ(openFAQ === index ? null : index);
    };
    const faqs = [
        {
            question: 'What subjects does Dr. Noor teach?',
            answer: 'Dr. Noor specializes in O Level and A Level Biology and Chemistry. With over 15 years of experience, she provides comprehensive coverage of both theoretical concepts and practical applications.'
        },
        {
            question: 'What are the class timings and schedule?',
            answer: 'We offer flexible timings to accommodate different student schedules. Classes are available in morning, afternoon, and evening slots. Weekend sessions are also available for working students.'
        },
        {
            question: 'How can I enroll in the classes?',
            answer: 'You can enroll by contacting us through WhatsApp, phone, or by visiting our academy. We offer both individual and group enrollment options with flexible payment plans.'
        },
        {
            question: 'Do you provide online classes?',
            answer: 'Yes, we offer both in-person and online classes. Our online sessions are interactive with live demonstrations, recorded lectures for revision, and personalized attention to each student.'
        },
        {
            question: 'What is the fee structure?',
            answer: 'Our fee structure is competitive and varies based on the subject, level (O Level/A Level), and class format (individual/group). Contact us for detailed fee information and available discounts.'
        },
        {
            question: 'Do you provide study materials?',
            answer: 'Yes, we provide comprehensive study materials including notes, past papers, practical guides, and additional resources. All materials are regularly updated according to the latest syllabus.'
        },
        {
            question: 'What is your success rate?',
            answer: 'We have an excellent track record with over 95% of our students achieving A* and A grades. Many of our students have secured admissions in top universities worldwide.'
        },
        {
            question: 'Do you offer trial classes?',
            answer: 'Yes, we offer a free trial class so you can experience our teaching methodology and decide if it suits your learning style. Contact us to schedule your trial session.'
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        id: "faq",
        className: "relative bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 py-20 px-4 sm:px-6 lg:px-8 overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 opacity-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-20 left-10 w-32 h-32 bg-amber-400/20 rounded-full blur-3xl animate-pulse"
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-20 right-10 w-40 h-40 bg-teal-400/20 rounded-full blur-3xl animate-pulse delay-1000"
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                        lineNumber: 72,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-1/2 left-1/4 w-24 h-24 bg-navy-400/15 rounded-full blur-2xl animate-pulse delay-500"
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-10 max-w-4xl mx-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center mb-16 transition-all duration-1000 ".concat(isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-4xl md:text-5xl font-bold text-white mb-6",
                                children: "❓ Frequently Asked Questions"
                            }, void 0, false, {
                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed",
                                children: "Find answers to common questions about our courses and services"
                            }, void 0, false, {
                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                lineNumber: 86,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: faqs.map((faq, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "transition-all duration-700 ".concat(isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'),
                                style: {
                                    transitionDelay: "".concat(index * 150, "ms")
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "group relative bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl overflow-hidden shadow-2xl hover:shadow-amber-500/20 transition-all duration-500 hover:border-amber-400/50 hover:bg-white/15",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-r from-amber-400/20 via-transparent to-amber-400/20 blur-sm"
                                        }, void 0, false, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                            lineNumber: 106,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>toggleFAQ(index),
                                            className: "relative w-full px-6 py-6 text-left flex items-center justify-between hover:bg-white/5 transition-all duration-300 group-hover:bg-white/10",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-lg font-semibold text-white pr-4 group-hover:text-amber-100 transition-colors duration-300",
                                                    children: faq.question
                                                }, void 0, false, {
                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                    lineNumber: 113,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-shrink-0 w-8 h-8 flex items-center justify-center transition-all duration-500 ".concat(openFAQ === index ? 'rotate-180 scale-110' : 'rotate-0 scale-100'),
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "relative",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "absolute w-6 h-6 text-amber-400 transition-all duration-300 ".concat(openFAQ === index ? 'opacity-0 rotate-90' : 'opacity-100 rotate-0'),
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                                    lineNumber: 137,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                                lineNumber: 127,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "absolute w-6 h-6 text-amber-400 transition-all duration-300 ".concat(openFAQ === index ? 'opacity-100 rotate-0' : 'opacity-0 -rotate-90'),
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M18 12H6"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                                    lineNumber: 156,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                                lineNumber: 146,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                        lineNumber: 125,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                    lineNumber: 118,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                            lineNumber: 109,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "overflow-hidden transition-all duration-700 ease-out ".concat(openFAQ === index ? 'max-h-96 opacity-100 translate-y-0' : 'max-h-0 opacity-0 -translate-y-4'),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "px-6 pb-6 border-t border-amber-400/20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "pt-4 transition-all duration-500 delay-100 ".concat(openFAQ === index ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'),
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$drnoor$2d$94468adde2afb22849fbd641cb281644be1032bc$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-gray-200 leading-relaxed",
                                                        children: faq.answer
                                                    }, void 0, false, {
                                                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                        lineNumber: 183,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                    lineNumber: 176,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                                lineNumber: 175,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                            lineNumber: 168,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                    lineNumber: 104,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, index, false, {
                                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx",
        lineNumber: 65,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(LazyFAQSection, "d+ViTGxsUZSITU7uQz5WZ9Fcob0=");
_c = LazyFAQSection;
const __TURBOPACK__default__export__ = LazyFAQSection;
var _c;
__turbopack_context__.k.register(_c, "LazyFAQSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/drnoor-94468adde2afb22849fbd641cb281644be1032bc/app/components/LazyFAQSection.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=f2147_68adde2afb22849fbd641cb281644be1032bc_app_components_LazyFAQSection_tsx_8d8c3f4a._.js.map