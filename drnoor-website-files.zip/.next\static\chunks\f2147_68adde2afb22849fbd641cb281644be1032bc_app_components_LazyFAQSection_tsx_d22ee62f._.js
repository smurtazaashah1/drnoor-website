(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f2147_68adde2afb22849fbd641cb281644be1032bc_app_components_LazyFAQSection_tsx_8d8c3f4a._.js"
],
    source: "dynamic"
});
